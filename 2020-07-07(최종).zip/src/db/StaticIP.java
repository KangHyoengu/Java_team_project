package db;

public class StaticIP {
	public static String ip = "192.168.100.34";
}
