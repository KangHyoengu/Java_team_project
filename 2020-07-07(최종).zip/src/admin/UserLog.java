package admin;

import data.UserListData;

public class UserLog {
	
	

}
