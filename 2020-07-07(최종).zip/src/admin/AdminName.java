package admin;

import javax.swing.JLabel;

public class AdminName {
	
	public static String id;
	public static JLabel idLabel;
}
