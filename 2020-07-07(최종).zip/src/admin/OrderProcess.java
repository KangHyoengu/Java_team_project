package admin;

import java.util.ArrayList;

import data.OrderInfo;

public class OrderProcess {
	ArrayList<OrderInfo> orders;
	
	
}
