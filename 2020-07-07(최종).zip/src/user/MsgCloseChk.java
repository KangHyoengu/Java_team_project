package user;

public class MsgCloseChk {
//	public boolean [] msgChk = new boolean[39];
	public boolean msgChk = false;

}
