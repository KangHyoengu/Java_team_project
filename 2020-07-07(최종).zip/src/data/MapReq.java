package data;

import java.io.Serializable;

public class MapReq implements Serializable{

	private static final long serialVersionUID = 40;

}
