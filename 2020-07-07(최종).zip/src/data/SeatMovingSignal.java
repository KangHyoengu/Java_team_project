package data;

import java.io.Serializable;

public class SeatMovingSignal implements Serializable {
	private static final long serialVersionUID = 5;
	
	public static boolean signal = false;
	
}
