package data;

import java.io.Serializable;
import java.util.TreeMap;

public class SeatInfo implements Serializable {
	
	private static final long serialVersionUID = 6;
	
}
