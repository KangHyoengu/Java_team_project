package data;

import java.io.Serializable;

public class UserInMap implements Serializable{

	private static final long serialVersionUID = 33;
	public String user;
	public boolean isIn = false;
	
	
}
