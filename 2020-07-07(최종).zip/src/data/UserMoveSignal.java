package data;

import java.io.Serializable;

public class UserMoveSignal implements Serializable{
	
	private static final long serialVersionUID = 9;
	
	public static boolean signal = false;
}
