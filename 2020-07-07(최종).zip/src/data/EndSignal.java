package data;

import java.io.Serializable;

public class EndSignal implements Serializable {

	private static final long serialVersionUID = 22;

}
