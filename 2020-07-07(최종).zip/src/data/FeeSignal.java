package data;

import java.io.Serializable;

public class FeeSignal implements Serializable{

	private static final long serialVersionUID = 51;

}
