package data;

public class AdminInfo {
	
	private static final long serialVersionUID = 13;
	
	public String id;

}
