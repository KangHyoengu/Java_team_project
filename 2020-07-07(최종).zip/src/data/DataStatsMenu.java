package data;

import java.util.ArrayList;

public class DataStatsMenu {

	public ArrayList<String> menuNameArr;
	public ArrayList<String> menuImgArr;
	public ArrayList<String> menuCntArr;
	

}
