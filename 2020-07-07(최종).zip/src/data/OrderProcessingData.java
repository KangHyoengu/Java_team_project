package data;

import java.util.ArrayList;

public class OrderProcessingData {
	
	public ArrayList<Object> arr;
	public ArrayList<Object> arrPanel;

}
